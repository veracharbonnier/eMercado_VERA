const CATEGORIES_URL = "https://japceibal.github.io/emercado-api/cats/cat.json";
const PUBLISH_PRODUCT_URL = "https://japceibal.github.io/emercado-api/sell/publish.json";
const PRODUCTS_URL = "https://japceibal.github.io/emercado-api/cats_products/";
const PRODUCT_INFO_URL = "https://japceibal.github.io/emercado-api/products/";
const PRODUCT_INFO_COMMENTS_URL = "https://japceibal.github.io/emercado-api/products_comments/";
const CART_INFO_URL = "https://japceibal.github.io/emercado-api/user_cart/";
const CART_BUY_URL = "https://japceibal.github.io/emercado-api/cart/buy.json";
const EXT_TYPE = ".json";

//función para mostrar el spinner de carga:
let showSpinner = function(){
  document.getElementById("spinner-wrapper").style.display = "block";
}

//función para ocultar el spinner de carga:
let hideSpinner = function(){
  document.getElementById("spinner-wrapper").style.display = "none";
}

//función que realiza el fetch() a la url recibida y devuelve un objeto con los datos y el estado de la respuesta:
let getJSONData =function (url){
    let result = {};
    showSpinner();
    return fetch(url)
    .then(response => {
      if (response.ok) {
        return response.json();
      }else{
        throw Error(response.statusText);
      }
    })
    .then(function(response) {
          result.status = 'ok';
          result.data = response;
          hideSpinner();
          return result;
    })
    .catch(function(error) {
        result.status = 'error';
        result.data = error;
        hideSpinner();
        return result;
    });
}

//función que lleva al login del usuario
document.addEventListener("DOMContentLoaded", ()=> {
  let user = localStorage.getItem("email"); //obtengo datos de localStorage
  if (user == undefined){
    alert("Inicia sesión para continuar");
    location.href = "login.html";
    } else {
  document.getElementById("email").innerHTML = user;
   }

})

//funcion para ver el usuario como pide el entregable 2
 let user = localStorage.getItem("email");
document.getElementById("input").innerHTML += user;

//cerrar sesion
document.getElementById("bye-bye").addEventListener("click", ()=>{
  localStorage.removeItem("email");
  document.getElementById("warning").classList.add("show");
})